export const TOAST_STYLE = {
    position: 'top-right',
    autoClose: 2500,
    closeOnClick: false,
    pauseOnHover: false,
    draggable: true,
    theme: 'colored'
}